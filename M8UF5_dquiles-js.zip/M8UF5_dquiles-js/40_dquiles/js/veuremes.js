function veureMes(){
    document.getElementById("mestext").className = "visible";
}