function on(un_element){
    un_element.src = "img/llumon.gif"
}
function off(un_element){
    un_element.src = "img/llumoff.gif"
}
function breaking(un_element){
    un_element.src = "img/llumbreak.gif"
}
document.addEventListener('keypress', logKey);
function logKey(e) {
  document.getElementById("un").textContent = ` ${1}`;
  document.getElementById("dos").textContent = ` ${2}`;
  document.getElementById("tres").textContent = ` ${3}`;
}
