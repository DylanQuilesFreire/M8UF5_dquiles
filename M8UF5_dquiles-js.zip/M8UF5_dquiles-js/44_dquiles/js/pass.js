function Validate() {
    var psw1 = document.getElementById("password").value;
    var psw2 = document.getElementById("conf.password").value;
    var usr = document.getElementById("User").value
    if (psw1 == "1234" && psw2 == psw1 && usr == "Ibai") {
        alert("Usuari i contrasenya correcte."); 
    }
    else{
        alert("Usuari i/o contrasenya incorrecte");
    }
}