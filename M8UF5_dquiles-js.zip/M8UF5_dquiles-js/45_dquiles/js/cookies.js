function Comprovar() {
    var psw1 = document.getElementById("password").value;
    var psw2 = document.getElementById("conf.password").value;
    if (psw1 == psw2){
        alert("Usuari i contrasenya correcte."); 
    }
    else{
        alert("Usuari i/o contrasenya incorrecte");
    }
}
function GDades(){
    var NomGuardat = document.getElementById("Guardanom").value;
    var CogGuardat = document.getElementById("Guardacognom").value;
    localStorage.setItem ("Guardanom", NomGuardat);
    localStorage.setItem ("Guardacognom", CogGuardat);
    document.getElementById("Guardanom").value = "";
    document.getElementById("Guardacognom").value = "";
}
function RDades(){
    var nombre = localStorage.getItem("Guardanom");
    var ape = localStorage.getItem("Guardacognom");
    document.getElementById("Guardanom").value = nombre;
    document.getElementById("Guardacognom").value = ape;
}
function EDades(){
    localStorage.clear();
    document.getElementById("Guardanom").value = "";
    document.getElementById("Guardacognom").value = "";
}