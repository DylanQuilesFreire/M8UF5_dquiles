function Validate() {
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("conf.password").value;
    if (password == confirmPassword) {
        alert("Password match."); 
    }
    else{
        alert("Passwords do not match.");
    }
}