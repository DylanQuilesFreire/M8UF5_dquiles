function calcula(numero){
	document.getElementById("operacion").value += numero;
}
function borrar(){
	document.getElementById("operacion").value = "";
}
function igual(){
	document.getElementById("operacion").value = eval(document.getElementById("operacion").value);
}
